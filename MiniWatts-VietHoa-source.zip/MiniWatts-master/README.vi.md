# MiniWatts – bản bổ sung tiếng Việt

Đây là bản mã nguồn MiniWatts được bổ sung bản dịch tiếng Việt trong `Localizable.xcstrings`.

## Cách dùng
- Mở `MiniWatts.xcodeproj` bằng Xcode 26 trở lên trên macOS.
- Chọn scheme `MiniWatts`, thiết bị iPhone và cấu hình ký bằng Apple ID của bạn.
- Build/Run hoặc Archive để tạo ứng dụng cài lên thiết bị.
- Trên iPhone, đặt ngôn ngữ ứng dụng là Tiếng Việt (nếu iOS hiển thị lựa chọn ngôn ngữ riêng cho ứng dụng), hoặc đặt Tiếng Việt làm ngôn ngữ ưu tiên của hệ thống.

## Lưu ý
- Đây là **mã nguồn đã thêm bản dịch**, không phải IPA đã biên dịch/ký.
- Những chuỗi chưa có bản dịch tiếng Việt sẽ tự dùng tiếng Anh gốc.
- Không thay đổi mã đo cảm biến, tính toán công suất hay logic sạc của dự án.
- MiniWatts dùng API riêng tư của iOS và cần cài ngoài App Store theo hướng dẫn của dự án gốc.
